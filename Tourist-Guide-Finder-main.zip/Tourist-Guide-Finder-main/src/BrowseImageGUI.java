import javax.swing.*;

public class BrowseImageGUI {
    private JPanel rootPanel;
    private JButton browseButton;
}
