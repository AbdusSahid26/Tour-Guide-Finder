package com.company;

public class MySearchGUI {
}
